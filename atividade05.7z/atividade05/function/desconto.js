import PromptSync from "prompt-sync";

const prompt =PromptSync()

function calcularPrecoComDesconto(valorProduct,qtdProduct,desconto){

    let precoFinal = (valorProduct*qtdProduct)*(-(desconto/100-1))
    return precoFinal
}
const lastPrice=calcularPrecoComDesconto((prompt("Digite o valor do produto: ")),(prompt("Qual a quantidade do produto: ")),(prompt("% de desconto desta compra: ")))
console.log(`O valor final a ser cobrado com desconto e´de R$${lastPrice}`)