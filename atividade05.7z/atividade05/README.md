# atividade04
Atividade referente a funções e laços de repetições 
